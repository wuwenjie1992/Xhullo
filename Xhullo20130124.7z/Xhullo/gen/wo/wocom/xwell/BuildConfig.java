/** Automatically generated file. DO NOT MODIFY */
package wo.wocom.xwell;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}